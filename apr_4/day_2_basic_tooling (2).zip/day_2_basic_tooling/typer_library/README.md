Example Typer application to show the benefits of using a command-line interface library.

```
python3 -m venv venv
. venv/bin/activate
pip install typer==0.6.1

python example.py
```
