An example module that contains a method without type annotations
to experiment with Python typing and mypy.
