An example database to be loaded to SQLFiddle.

First, create a new SQLFiddle and then add the database from `db.sql`
to be able to perform example queries.
