A database to be loaded to SQLFiddle to perform warm-up SQL task.

First, create a new SQLFiddle and then add the database from `db.sql`
to be able to perform queries.
