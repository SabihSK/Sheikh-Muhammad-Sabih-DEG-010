This directory contains an example application that uses SQLAlchemy ORM.

To run, use:

```
python3 -m virtualenv venv
. venv/bin/activate
pip install SQLAlchemy==1.4.41

python example.py
```
