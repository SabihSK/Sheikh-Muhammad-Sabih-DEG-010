This directory contains a script that starts a test PostgreSQL instance
so that the participants can use DBeaver on it.

DBeaver can be downloaded from https://dbeaver.io/ .
