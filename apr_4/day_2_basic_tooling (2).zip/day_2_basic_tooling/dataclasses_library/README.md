An example module with a dataclass to show the benefits of using dataclasses.
