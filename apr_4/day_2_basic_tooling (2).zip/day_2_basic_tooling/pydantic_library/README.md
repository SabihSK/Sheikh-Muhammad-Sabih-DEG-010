This directory contains an example Pydantic model the participants can play with.

To run, use:

```
python3 -m virtualenv venv
. venv/bin/activate
pip install pydantic==1.10.2

python example.py
```
